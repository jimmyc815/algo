# battatech_excelexport jQuery Plugin
[Documentation] (http://battatech.com/blog/how-to-export-to-excel-sheet-on-client-side)
